export const deepCopy = (obj: any): any => JSON.parse(JSON.stringify(obj));
