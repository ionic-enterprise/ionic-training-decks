import { Storage } from '@capacitor/storage';
import { VaultError } from '@ionic-enterprise/identity-vault';

export class BrowserVault {
  async doesVaultExist(): Promise<boolean> {
    return true;
  }

  clear(): Promise<void> {
    return Storage.clear();
  }

  exportVault() {
    console.log('exporting the browser vault?');
  }

  importVault(data: { [key: string]: string }) {
    console.log('importing the browser vault?', data);
  }

  async isLocked(): Promise<boolean> {
    return false;
  }

  async getKeys(): Promise<Array<string>> {
    return (await Storage.keys())?.keys;
  }

  async getValue(key: string): Promise<any | undefined> {
    const value = (await Storage.get({ key }))?.value;
    if (value) {
      return JSON.parse(value);
    }
  }

  lock(): Promise<void> {
    return Promise.resolve();
  }

  removeValue(key: string): Promise<void> {
    return Storage.remove({ key });
  }

  setCustomPasscode(passcode: string): Promise<void> {
    console.log('should not set passcode on a browser vault');
    return Promise.resolve();
  }

  setValue(key: string, value: any): Promise<void> {
    return Storage.set({ key, value: JSON.stringify(value) });
  }

  onConfigChanged(callback: (config: any) => void) {}

  onError(callback: (err: VaultError) => void) {}

  onLock(callback: () => void) {}

  onPasscodeRequested(callback: () => Promise<void>) {}

  onUnlock(callback: () => void) {}

  unlock(): Promise<void> {
    return Promise.resolve();
  }

  updateConfig(config: any) {
    console.log('update config?', config);
  }
}
