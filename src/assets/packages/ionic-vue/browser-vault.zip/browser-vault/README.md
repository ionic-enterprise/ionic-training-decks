# Browser Vault Implementations

The "Browser Vault" implements the Identity Vault API in the browser so you can continue to use a browser as part of your normal development workflow while keeping a single application code base. This is _not_ intended for securely storing the tokens in a web based application.

This zip file contains two sets of implementations:

- The legacy API:
  - `BrowserVaultPlugin.ts`
  - `BrowserVaultService.ts`
- The modern API: `BrowserVault.ts`

Be sure to use the file(s) associated with whichever API you are using. If you are following a tutorial, the tutorial will tell you which file(s) to use.
